package fr.rouen.mastergil;

public enum Devise {
    DOLLAR,
    EURO,
    LIVRE,
    YEN,
    PESO,
    DINAR
}
