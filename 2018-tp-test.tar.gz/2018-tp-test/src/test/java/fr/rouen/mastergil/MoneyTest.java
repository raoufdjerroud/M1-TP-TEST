package fr.rouen.mastergil;

import org.assertj.core.api.AbstractIterableSizeAssert;
import org.assertj.core.api.IntegerAssert;
import org.junit.Test;
import static org.assertj.core.api.Assertions.*;
//import static org.junit.Assert.*;

public class MoneyTest {

    @Test
    public void constructAvecArguments()
    {
        //GIVEN/WHEN
        Money ney= new Money(121212,Devise.EURO);
        //THEN
        assertThat(ney.getMontant()).isEqualTo(121212);
        assertThat(ney.getDevise()).isEqualTo(Devise.EURO);



    }

    @Test
    public void constructSansArguments()
    {
        //GIVEN/WHEN
        Money ney=new Money();
        //THEN
        assertThat(ney.getMontant()).isEqualTo(0);
        assertThat(ney.getDevise()).isEqualTo(Devise.PESO);

    }
    @Test
    public void constructValeursVides()
    {





        try {
            //GIVEN/WHEN
            Money ney = new Money(0,null);
            //THEN
            assertThat(ney.getMontant()).isEqualTo(0);
            fail("une exception IllegalArgumentException est attendu");
        }catch (IllegalArgumentException e){

            assertThat(e.getMessage()).isEqualTo("Devise doit être spécifiée");


        }
    }
    @Test
    public void valuerNonGere()
    {
        //GIVEN/WHEN
        Money ney = new Money();
        //THEN
        ney.getMontant();
    }

    @Test
    public void isPositifReturnFalse() throws Exception {
    //GIVEN/WHEN
        Money ney = new Money(-50,Devise.YEN);
        //THEN
        assertThat(ney.isPositif()).isFalse();

    }
    @Test
    public void isPositifReturnTrue() throws Exception {
        //GIVEN/WHEN
        Money ney = new Money(50,Devise.YEN);
        //THEN
        assertThat(ney.isPositif()).isTrue();

    }
    @Test
    public void getMontantReturnInt() throws Exception {
        //GIVEN/WHEN
        Money ney = new Money(50,Devise.YEN);
        //THEN

    }

    @Test
    public void setMontant() throws Exception {
    }

    @Test
    public void getDevise() throws Exception {
    }

    @Test
    public void setDevise() throws Exception {
    }

    @Test
    public void increaseMontant() throws Exception {
    }

    @Test
    public void decreaseMontant() throws Exception {
    }

}