# 2017-tp-test

Master 1 GIL 

## TP 1 :
Ecrire les tests unitaire de la classe Money :

* contructeur avec des valeurs vides
* contructeur avec des valeurs
* constructeur sans valeur
* constructeur avec des valeurs non gérés
* toutes les méthodes et cas de test
